using Verse;

namespace RimWorld
{
	public class BillStoreModeDef : Def
	{
		public int listOrder;
	}
}
