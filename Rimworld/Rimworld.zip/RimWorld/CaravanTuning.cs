namespace RimWorld
{
	public static class CaravanTuning
	{
		public const float JoyGainPerHourNotMoving = 0.1f;

		public const int JoyGainIntervalTicks = 1250;
	}
}
