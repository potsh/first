namespace RimWorld
{
	public class CompProperties_TerrainPumpDry : CompProperties_TerrainPump
	{
		public CompProperties_TerrainPumpDry()
		{
			compClass = typeof(CompTerrainPumpDry);
		}
	}
}
