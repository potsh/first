namespace RimWorld
{
	public enum BuySellMode : byte
	{
		Buying,
		Selling
	}
}
