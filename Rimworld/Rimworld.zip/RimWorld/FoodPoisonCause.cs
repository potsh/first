namespace RimWorld
{
	public enum FoodPoisonCause
	{
		Unknown,
		IncompetentCook,
		FilthyKitchen,
		Rotten,
		DangerousFoodType
	}
}
