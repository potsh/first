namespace RimWorld
{
	public enum FactionRelationKind
	{
		Hostile,
		Neutral,
		Ally
	}
}
