using Verse;

namespace RimWorld
{
	public class CompProperties_SpawnerMechanoidsOnDamaged : CompProperties
	{
		public CompProperties_SpawnerMechanoidsOnDamaged()
		{
			compClass = typeof(CompSpawnerMechanoidsOnDamaged);
		}
	}
}
