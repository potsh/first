namespace RimWorld
{
	public enum Direction8Way
	{
		North,
		NorthEast,
		East,
		SouthEast,
		South,
		SouthWest,
		West,
		NorthWest
	}
}
