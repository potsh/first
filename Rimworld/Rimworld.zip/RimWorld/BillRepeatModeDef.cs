using Verse;

namespace RimWorld
{
	public class BillRepeatModeDef : Def
	{
		public int listOrder;
	}
}
