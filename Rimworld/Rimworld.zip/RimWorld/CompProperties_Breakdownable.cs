using Verse;

namespace RimWorld
{
	public class CompProperties_Breakdownable : CompProperties
	{
		public CompProperties_Breakdownable()
		{
			compClass = typeof(CompBreakdownable);
		}
	}
}
