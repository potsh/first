namespace RimWorld
{
	public enum DrugDesireCategory : byte
	{
		Withdrawal,
		Desire,
		Satisfied
	}
}
