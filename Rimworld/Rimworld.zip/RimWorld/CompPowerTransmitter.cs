namespace RimWorld
{
	public class CompPowerTransmitter : CompPower
	{
	}
}
