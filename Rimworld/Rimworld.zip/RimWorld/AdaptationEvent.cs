namespace RimWorld
{
	public enum AdaptationEvent
	{
		Downed,
		Died,
		Kidnapped,
		LostBecauseMapClosed
	}
}
