using Verse;

namespace RimWorld
{
	public class Designator_ZoneDelete_Shrink : Designator_ZoneDelete
	{
		public Designator_ZoneDelete_Shrink()
		{
			defaultLabel = "DesignatorZoneDeleteSingular".Translate();
			defaultDesc = "DesignatorZoneDeleteDesc".Translate();
		}
	}
}
