namespace RimWorld
{
	public enum ArtGenerationContext : byte
	{
		Outsider,
		Colony
	}
}
