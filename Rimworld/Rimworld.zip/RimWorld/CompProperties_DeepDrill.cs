using Verse;

namespace RimWorld
{
	public class CompProperties_DeepDrill : CompProperties
	{
		public CompProperties_DeepDrill()
		{
			compClass = typeof(CompDeepDrill);
		}
	}
}
