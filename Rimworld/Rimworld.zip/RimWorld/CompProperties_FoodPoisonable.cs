using Verse;

namespace RimWorld
{
	public class CompProperties_FoodPoisonable : CompProperties
	{
		public CompProperties_FoodPoisonable()
		{
			compClass = typeof(CompFoodPoisonable);
		}
	}
}
