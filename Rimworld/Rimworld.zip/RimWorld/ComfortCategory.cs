namespace RimWorld
{
	public enum ComfortCategory : byte
	{
		Uncomfortable,
		Normal,
		Comfortable,
		VeryComfortable,
		ExtremelyComfortable,
		LuxuriantlyComfortable
	}
}
