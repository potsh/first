namespace RimWorld
{
	public enum AlertPriority : byte
	{
		Medium,
		High,
		Critical
	}
}
