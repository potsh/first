using Verse;

namespace RimWorld
{
	public class CompProperties_Launchable : CompProperties
	{
		public CompProperties_Launchable()
		{
			compClass = typeof(CompLaunchable);
		}
	}
}
