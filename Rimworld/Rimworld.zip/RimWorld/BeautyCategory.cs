namespace RimWorld
{
	public enum BeautyCategory : byte
	{
		Hideous,
		VeryUgly,
		Ugly,
		Neutral,
		Pretty,
		VeryPretty,
		Beautiful
	}
}
