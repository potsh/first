using Verse;

namespace RimWorld
{
	public class CompProperties_CreatesInfestations : CompProperties
	{
		public CompProperties_CreatesInfestations()
		{
			compClass = typeof(CompCreatesInfestations);
		}
	}
}
