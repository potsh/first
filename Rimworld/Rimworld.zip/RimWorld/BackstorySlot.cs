namespace RimWorld
{
	public enum BackstorySlot : byte
	{
		Childhood,
		Adulthood
	}
}
