namespace RimWorld
{
	public static class AvoidGridTuning
	{
		public const byte MaxValue = byte.MaxValue;

		public const int PathCostFactor = 8;

		public const int CostForTurretLOS = 45;
	}
}
