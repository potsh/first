using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace RimWorld
{
	public class Designator_Build : Designator_Place
	{
		protected BuildableDef entDef;

		private ThingDef stuffDef;

		private bool writeStuff;

		private static readonly Vector2 TerrainTextureCroppedSize = new Vector2(64f, 64f);

		private static readonly Vector2 DragPriceDrawOffset = new Vector2(19f, 17f);

		private const float DragPriceDrawNumberX = 29f;

		public override BuildableDef PlacingDef => entDef;

		public override string Label
		{
			get
			{
				ThingDef thingDef = entDef as ThingDef;
				if (thingDef != null && writeStuff)
				{
					return GenLabel.ThingLabel(thingDef, stuffDef);
				}
				if (thingDef != null && thingDef.MadeFromStuff)
				{
					return entDef.label + "...";
				}
				return entDef.label;
			}
		}

		public override string Desc => entDef.description;

		public override Color IconDrawColor
		{
			get
			{
				if (stuffDef != null)
				{
					return stuffDef.stuffProps.color;
				}
				return entDef.uiIconColor;
			}
		}

		public override bool Visible
		{
			get
			{
				if (DebugSettings.godMode)
				{
					return true;
				}
				if (entDef.minTechLevelToBuild != 0 && (int)Faction.OfPlayer.def.techLevel < (int)entDef.minTechLevelToBuild)
				{
					return false;
				}
				if (entDef.maxTechLevelToBuild != 0 && (int)Faction.OfPlayer.def.techLevel > (int)entDef.maxTechLevelToBuild)
				{
					return false;
				}
				if (!entDef.IsResearchFinished)
				{
					return false;
				}
				if (entDef.buildingPrerequisites != null)
				{
					for (int i = 0; i < entDef.buildingPrerequisites.Count; i++)
					{
						if (!base.Map.listerBuildings.ColonistsHaveBuilding(entDef.buildingPrerequisites[i]))
						{
							return false;
						}
					}
				}
				return true;
			}
		}

		public override int DraggableDimensions => entDef.placingDraggableDimensions;

		public override bool DragDrawMeasurements => true;

		public override float PanelReadoutTitleExtraRightMargin => 20f;

		public override string HighlightTag
		{
			get
			{
				if (cachedHighlightTag == null && tutorTag != null)
				{
					cachedHighlightTag = "Designator-Build-" + tutorTag;
				}
				return cachedHighlightTag;
			}
		}

		public Designator_Build(BuildableDef entDef)
		{
			this.entDef = entDef;
			icon = entDef.uiIcon;
			iconAngle = entDef.uiIconAngle;
			iconOffset = entDef.uiIconOffset;
			hotKey = entDef.designationHotKey;
			tutorTag = entDef.defName;
			order = 20f;
			ThingDef thingDef = entDef as ThingDef;
			if (thingDef != null)
			{
				iconProportions = thingDef.graphicData.drawSize.RotatedBy(thingDef.defaultPlacingRot);
				iconDrawScale = GenUI.IconDrawScale(thingDef);
			}
			else
			{
				iconProportions = new Vector2(1f, 1f);
				iconDrawScale = 1f;
			}
			TerrainDef terrainDef = entDef as TerrainDef;
			if (terrainDef != null)
			{
				Vector2 terrainTextureCroppedSize = TerrainTextureCroppedSize;
				float width = terrainTextureCroppedSize.x / (float)icon.width;
				Vector2 terrainTextureCroppedSize2 = TerrainTextureCroppedSize;
				iconTexCoords = new Rect(0f, 0f, width, terrainTextureCroppedSize2.y / (float)icon.height);
			}
			ResetStuffToDefault();
		}

		public override GizmoResult GizmoOnGUI(Vector2 topLeft, float maxWidth)
		{
			GizmoResult result = base.GizmoOnGUI(topLeft, maxWidth);
			ThingDef thingDef = entDef as ThingDef;
			if (thingDef != null && thingDef.MadeFromStuff)
			{
				Designator_Dropdown.DrawExtraOptionsIcon(topLeft, GetWidth(maxWidth));
			}
			return result;
		}

		public void ResetStuffToDefault()
		{
			ThingDef thingDef = entDef as ThingDef;
			if (thingDef != null && thingDef.MadeFromStuff)
			{
				stuffDef = GenStuff.DefaultStuffFor(thingDef);
			}
		}

		public override void DrawMouseAttachments()
		{
			base.DrawMouseAttachments();
			if (!ArchitectCategoryTab.InfoRect.Contains(UI.MousePositionOnUIInverted))
			{
				DesignationDragger dragger = Find.DesignatorManager.Dragger;
				int num = (!dragger.Dragging) ? 1 : dragger.DragCells.Count();
				float num2 = 0f;
				Vector2 vector = Event.current.mousePosition + DragPriceDrawOffset;
				List<ThingDefCountClass> list = entDef.CostListAdjusted(stuffDef);
				for (int i = 0; i < list.Count; i++)
				{
					ThingDefCountClass thingDefCountClass = list[i];
					float y = vector.y + num2;
					Rect rect = new Rect(vector.x, y, 27f, 27f);
					Widgets.ThingIcon(rect, thingDefCountClass.thingDef);
					Rect rect2 = new Rect(vector.x + 29f, y, 999f, 29f);
					int num3 = num * thingDefCountClass.count;
					string text = num3.ToString();
					if (base.Map.resourceCounter.GetCount(thingDefCountClass.thingDef) < num3)
					{
						GUI.color = Color.red;
						text = text + " (" + "NotEnoughStoredLower".Translate() + ")";
					}
					Text.Font = GameFont.Small;
					Text.Anchor = TextAnchor.MiddleLeft;
					Widgets.Label(rect2, text);
					Text.Anchor = TextAnchor.UpperLeft;
					GUI.color = Color.white;
					num2 += 29f;
				}
			}
		}

		public override void ProcessInput(Event ev)
		{
			if (CheckCanInteract())
			{
				ThingDef thingDef = entDef as ThingDef;
				if (thingDef == null || !thingDef.MadeFromStuff)
				{
					base.ProcessInput(ev);
				}
				else
				{
					List<FloatMenuOption> list = new List<FloatMenuOption>();
					foreach (ThingDef key in base.Map.resourceCounter.AllCountedAmounts.Keys)
					{
						if (key.IsStuff && key.stuffProps.CanMake(thingDef) && (DebugSettings.godMode || base.Map.listerThings.ThingsOfDef(key).Count > 0))
						{
							ThingDef localStuffDef = key;
							string label = GenLabel.ThingLabel(entDef, localStuffDef).CapitalizeFirst();
							FloatMenuOption floatMenuOption = new FloatMenuOption(label, delegate
							{
								base.ProcessInput(ev);
								Find.DesignatorManager.Select(this);
								stuffDef = localStuffDef;
								writeStuff = true;
							});
							floatMenuOption.tutorTag = "SelectStuff-" + thingDef.defName + "-" + localStuffDef.defName;
							list.Add(floatMenuOption);
						}
					}
					if (list.Count == 0)
					{
						Messages.Message("NoStuffsToBuildWith".Translate(), MessageTypeDefOf.RejectInput, historical: false);
					}
					else
					{
						FloatMenu floatMenu = new FloatMenu(list);
						floatMenu.vanishIfMouseDistant = true;
						floatMenu.onCloseCallback = delegate
						{
							writeStuff = true;
						};
						Find.WindowStack.Add(floatMenu);
						Find.DesignatorManager.Select(this);
					}
				}
			}
		}

		public override AcceptanceReport CanDesignateCell(IntVec3 c)
		{
			return GenConstruct.CanPlaceBlueprintAt(entDef, c, placingRot, base.Map, DebugSettings.godMode);
		}

		public override void DesignateSingleCell(IntVec3 c)
		{
			if (!TutorSystem.TutorialMode || TutorSystem.AllowAction(new EventPack(base.TutorTagDesignate, c)))
			{
				if (DebugSettings.godMode || entDef.GetStatValueAbstract(StatDefOf.WorkToBuild, stuffDef) == 0f)
				{
					if (entDef is TerrainDef)
					{
						base.Map.terrainGrid.SetTerrain(c, (TerrainDef)entDef);
					}
					else
					{
						Thing thing = ThingMaker.MakeThing((ThingDef)entDef, stuffDef);
						thing.SetFactionDirect(Faction.OfPlayer);
						GenSpawn.Spawn(thing, c, base.Map, placingRot);
					}
				}
				else
				{
					GenSpawn.WipeExistingThings(c, placingRot, entDef.blueprintDef, base.Map, DestroyMode.Deconstruct);
					GenConstruct.PlaceBlueprintForBuild(entDef, c, base.Map, placingRot, Faction.OfPlayer, stuffDef);
				}
				MoteMaker.ThrowMetaPuffs(GenAdj.OccupiedRect(c, placingRot, entDef.Size), base.Map);
				ThingDef thingDef = entDef as ThingDef;
				if (thingDef != null && thingDef.IsOrbitalTradeBeacon)
				{
					PlayerKnowledgeDatabase.KnowledgeDemonstrated(ConceptDefOf.BuildOrbitalTradeBeacon, KnowledgeAmount.Total);
				}
				if (TutorSystem.TutorialMode)
				{
					TutorSystem.Notify_Event(new EventPack(base.TutorTagDesignate, c));
				}
				if (entDef.PlaceWorkers != null)
				{
					for (int i = 0; i < entDef.PlaceWorkers.Count; i++)
					{
						entDef.PlaceWorkers[i].PostPlace(base.Map, entDef, c, placingRot);
					}
				}
			}
		}

		public override void SelectedUpdate()
		{
			base.SelectedUpdate();
			BuildDesignatorUtility.TryDrawPowerGridAndAnticipatedConnection(entDef, placingRot);
		}

		public override void DrawPanelReadout(ref float curY, float width)
		{
			if (entDef.costStuffCount <= 0 && stuffDef != null)
			{
				stuffDef = null;
			}
			ThingDef thingDef = entDef as ThingDef;
			if (thingDef != null)
			{
				Widgets.InfoCardButton(width - 24f - 2f, 6f, thingDef, stuffDef);
			}
			else
			{
				Widgets.InfoCardButton(width - 24f - 2f, 6f, entDef);
			}
			Text.Font = GameFont.Small;
			List<ThingDefCountClass> list = entDef.CostListAdjusted(stuffDef, errorOnNullStuff: false);
			for (int i = 0; i < list.Count; i++)
			{
				ThingDefCountClass thingDefCountClass = list[i];
				Color color = GUI.color;
				Widgets.ThingIcon(new Rect(0f, curY, 20f, 20f), thingDefCountClass.thingDef);
				GUI.color = color;
				if (thingDefCountClass.thingDef != null && thingDefCountClass.thingDef.resourceReadoutPriority != 0 && base.Map.resourceCounter.GetCount(thingDefCountClass.thingDef) < thingDefCountClass.count)
				{
					GUI.color = Color.red;
				}
				Widgets.Label(new Rect(26f, curY + 2f, 50f, 100f), thingDefCountClass.count.ToString());
				GUI.color = Color.white;
				string text = (thingDefCountClass.thingDef != null) ? thingDefCountClass.thingDef.LabelCap : ("(" + "UnchosenStuff".Translate() + ")");
				float width2 = width - 60f;
				float num = Text.CalcHeight(text, width2) - 5f;
				Widgets.Label(new Rect(60f, curY + 2f, width2, num + 5f), text);
				curY += num;
			}
			if (entDef.constructionSkillPrerequisite > 0)
			{
				Rect rect = new Rect(0f, curY + 2f, width, 24f);
				if (!AnyColonistWithConstructionSkill(entDef.constructionSkillPrerequisite, careIfDisabled: false))
				{
					GUI.color = Color.red;
					TooltipHandler.TipRegion(rect, "NoColonistWithConstructionSkillTip".Translate(Faction.OfPlayer.def.pawnsPlural));
				}
				else if (!AnyColonistWithConstructionSkill(entDef.constructionSkillPrerequisite, careIfDisabled: true))
				{
					GUI.color = Color.yellow;
					TooltipHandler.TipRegion(rect, "AllColonistsWithConstructionSkillHaveDisaledConstructingTip".Translate(Faction.OfPlayer.def.pawnsPlural, WorkTypeDefOf.Construction.gerundLabel));
				}
				else
				{
					GUI.color = new Color(0.72f, 0.87f, 0.72f);
				}
				Widgets.Label(rect, string.Format("{0}: {1}", "ConstructionNeeded".Translate(), entDef.constructionSkillPrerequisite));
				GUI.color = Color.white;
				curY += 18f;
			}
			curY += 4f;
		}

		private bool AnyColonistWithConstructionSkill(int skill, bool careIfDisabled)
		{
			foreach (Pawn freeColonist in Find.CurrentMap.mapPawns.FreeColonists)
			{
				if (freeColonist.skills.GetSkill(SkillDefOf.Construction).Level >= skill && (!careIfDisabled || freeColonist.workSettings.WorkIsActive(WorkTypeDefOf.Construction)))
				{
					return true;
				}
			}
			return false;
		}

		public void SetStuffDef(ThingDef stuffDef)
		{
			this.stuffDef = stuffDef;
		}

		public override void RenderHighlight(List<IntVec3> dragCells)
		{
			DesignatorUtility.RenderHighlightOverSelectableCells(this, dragCells);
		}
	}
}
