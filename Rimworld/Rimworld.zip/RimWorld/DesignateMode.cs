namespace RimWorld
{
	public enum DesignateMode : byte
	{
		Add,
		Remove
	}
}
