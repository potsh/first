using Verse;

namespace RimWorld
{
	public class CompProperties_Ingredients : CompProperties
	{
		public CompProperties_Ingredients()
		{
			compClass = typeof(CompIngredients);
		}
	}
}
