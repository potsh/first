using Verse;

namespace RimWorld
{
	public class Building_ResearchBench : Building
	{
	}
}
