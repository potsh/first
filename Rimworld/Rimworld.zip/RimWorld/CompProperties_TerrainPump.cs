using Verse;

namespace RimWorld
{
	public abstract class CompProperties_TerrainPump : CompProperties
	{
		public float radius = 5.9f;

		public float daysToRadius = 5f;
	}
}
