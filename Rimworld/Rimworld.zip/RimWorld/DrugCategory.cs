namespace RimWorld
{
	public enum DrugCategory
	{
		None,
		Medical,
		Social,
		Hard,
		Any
	}
}
