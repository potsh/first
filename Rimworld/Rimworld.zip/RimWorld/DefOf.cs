using System;

namespace RimWorld
{
	[AttributeUsage(AttributeTargets.Class)]
	public class DefOf : Attribute
	{
	}
}
